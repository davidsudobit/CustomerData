package com.ikano.dmsmigrationannualdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmsMigrationAnnualDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
