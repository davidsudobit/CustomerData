package com.ikano.dmsmigrationannualdata.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.ikano.dmsmigrationannualdata.model.*;

import javax.management.openmbean.InvalidKeyException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.zip.DataFormatException;

@Service
public class CsvProcessorService {

    @Autowired
    @Lazy
    private PdfService pdfService;

    @Autowired
    private Headings headingsConfig;

    private static List<String> accountDataHeadings;

    private static List<String> summaryDataHeadings;

    private static LinkedHashMap<String, List<String[]>> accountData;

    private static LinkedHashMap<String,List<String[]>> summaryData;

    private static LinkedHashMap<String, String> headingsTranslation;

    @Async
    public void generatePdf(PathData pathData) throws Exception {

        validatePathdata(pathData);
        pathData.setDestPdfPath(pathData.getDestPdfPath()!=null?pathData.getDestPdfPath():headingsConfig.getPdfDestPath());

        processCustomerDataCustom(pathData.getAccountDataCsv());
        processSummaryDataCustom(pathData.getSummaryDataCsv());
        translationMapper();

        List<CustomerData> customerDatas=null;

        try {

            customerDatas=loadAllData();

        }
        catch(DataFormatException e) {

            System.out.println("Error in processing CSV :( ; Error Details : [ "+e.getMessage()+" ]");
            return;

        }
        finally {

            accountDataHeadings.clear();
            summaryDataHeadings.clear();
            accountData.clear();
            summaryData.clear();

        }

        System.out.print("\n<<<<< PDF Generation Started >>>>>\n");

//        System.out.println("\n"+pdfService.generatePdf(pathData, customerDatas.get(0))+"\n");

        customerDatas.forEach(customerData->{

            try {

                System.out.print("\n"+pdfService.generatePdf(pathData, customerData)+"\n");

            } catch (Exception e) {

                System.out.printf("Error Generating PDF : [ %s ]", pathData.getDestPdfPath()+String.format("%s_%s.pdf", customerData.getSsn(),customerData.getSummaryData().getSummaryYear()));

            }

        });

        System.out.print("\n<<<<< PDF Generation Completed >>>>>\n");

    }

    public void processCustomerDataCustom(String sourcePath) throws Exception {

        sourcePath=sourcePath==null?headingsConfig.getAccountCSVDefaultPath():sourcePath;

        List<String> inputLines=getFileData(sourcePath);
        List<String[]> inputData=parseAndSplitInputData(inputLines);

        accountDataHeadings=new LinkedList<>(Arrays.asList(inputData.remove(0)));
        accountData=removeDuplicates(inputData, accountDataHeadings);

    }

    public void processSummaryDataCustom(String sourcePath) throws IOException, DataFormatException {

        sourcePath=sourcePath==null?headingsConfig.getSummaryCSVDefaultPath():sourcePath;

        List<String> fileData=getFileData(sourcePath);
        List<String[]> linesData=parseAndSplitInputData(fileData);

        summaryDataHeadings=new LinkedList<>(Arrays.asList(linesData.remove(0)));
        summaryData=removeDuplicates(linesData, summaryDataHeadings);

    }

    private List<String[]> parseAndSplitInputData(List<String> inputLines) {

        return inputLines.stream().map(line->{

            String datas[]=line.split(";");

            for(int i=0;i<datas.length; i++) {

                datas[i]=datas[i].replace("\"", "").replace("\uFEFF","").trim();

            }

            return datas;

        }).collect(Collectors.toList());

    }

    private LinkedHashMap<String, List<String[]>> removeDuplicates(List<String[]> datas, List<String> headings){

        Map<String,List<String[]>> datasMap = datas.stream().collect(Collectors.groupingBy(inputDatas->inputDatas[getIndexOfHeading(headings, headingsConfig.getSsn())],LinkedHashMap<String, List<String[]>>::new, Collectors.mapping(Function.identity(), Collectors.toList())));

        return datasMap.entrySet().stream().map(entry->{

            List<String[]> dataList=entry.getValue();

            return dataList.stream().map(inputDatas->{

                        StringJoiner stringJoiner=new StringJoiner(";");

                        for(String inputData: inputDatas) {

                            stringJoiner.add(inputData);

                        }

                        return stringJoiner.toString();

                    }).distinct()
                    .map(uniqueData->{

                        return uniqueData.split(";");

                    });

        }).flatMap(Function.identity()).collect(Collectors.groupingBy(processedData->processedData[getIndexOfHeading(headings, headingsConfig.getSsn())], LinkedHashMap<String,List<String[]>>::new, Collectors.mapping(Function.<String[]>identity(), Collectors.toList())));

    }

    private List<AccountData> loadAccountDataCustom(List<String[]> inputData){

        Integer savingsAccountIndexes[]=loadIndexesForAccount(accountDataHeadings, headingsConfig.getSavingsAccount());
        Integer loanAccountIndexes[]=loadIndexesForAccount(accountDataHeadings, headingsConfig.getLoanAccount());
        Integer tillvaxtAccountIndexes[]=loadIndexesForAccount(accountDataHeadings, headingsConfig.getTillVaxtAccount());
        Integer borsAccountIndexes[]=loadIndexesForAccount(accountDataHeadings, headingsConfig.getBorsAccount());

        return inputData.stream().map(datas->{

            List<DataHolder> listOfData=new LinkedList<>();

            String accountId=preceddingZeroRemover(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getEngagementNumber())].toCharArray());

            AccountData accountData=new AccountData();

            accountData.setAccountName(String.join(" ", datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getProductText())], accountId));
            accountData.setDataHolder(listOfData);

            String customerAccountType=datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getEngagementType())];
            String productText=datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getProductText())];

            switch(customerAccountType) {

                case "" -> {

                    savingsAccount(accountData, datas, savingsAccountIndexes);

                }

                case "D" -> {

                    savingsAccount(accountData, datas, savingsAccountIndexes);

                }

                case "T" -> {

                    if(productText.toLowerCase().contains("TILLVÄXT".toLowerCase())) {

                        tillvaxtAccount(accountData, datas, tillvaxtAccountIndexes);

                    }
                    else if(productText.toLowerCase().contains("BÖRS".toLowerCase())) {

                        borsAccount(accountData, datas, borsAccountIndexes);

                    }
                    else if(productText.toLowerCase().contains("SPARKONTO FIX".toLowerCase())||productText.toLowerCase().contains("SPARKTO FIX".toLowerCase())||productText.toLowerCase().contains("FÖRETAGSKTO FIX".toLowerCase())) {

                        savingsAccount(accountData, datas, savingsAccountIndexes);

                    }

                }

                case "L" -> {

                    loanAccount(accountData, datas, loanAccountIndexes);

                }

            };

            return accountData;

        }).collect(Collectors.toList());

    }

    private SummaryData loadSummaryData(List<String[]> linesData) throws DataFormatException {

        SummaryData summaryDataOut= linesData.stream().map(datas->{

            SummaryData summaryData=new SummaryData();

            summaryData.setSummaryYear(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getYearConcerned())]);
            summaryData.setSumReceivedInterest(formatData(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getSumReceivedInterest())]));
            summaryData.setSumPreliminaryTax(formatData(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getSumPreliminaryTax())]));
            summaryData.setSumPaidInterest(formatData(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getSumPaidInterest())]));

            return summaryData;

        }).findFirst().orElseThrow(()->new DataFormatException("Summary data loading failed :("));

        return summaryDataOut;

    }

    private CustomerData loadCustomerData(List<String[]> inputDatas, CustomerData customerData) {

        inputDatas.forEach(datas->{

            customerData.setCustomerName(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getName())]);
            customerData.setCareOfAddress(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getCareOfAddress())]);
            customerData.setStreetName(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getStreetAddress())]);
            customerData.setPincode(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getPostalCode())]);
            customerData.setCity(datas[getIndexOfHeading(summaryDataHeadings, headingsConfig.getCity())]);

        });

        return customerData;

    }

    private List<CustomerData> loadAllData() throws DataFormatException{

        return accountData.entrySet().stream().map(entry->{

            CustomerData customerData=new CustomerData();

            String ssn=entry.getKey();
            List<AccountData> customerAccountData=loadAccountDataCustom(entry.getValue());
            SummaryData customerSummaryData=null;
            try {

                if(summaryData.containsKey(ssn)) {

                    customerSummaryData=loadSummaryData(summaryData.get(ssn));
                    customerData=loadCustomerData(summaryData.get(ssn), customerData);

                }

            } catch (DataFormatException e) {

            }

            customerData.setSsn(ssn);
            customerData.setAccountData(customerAccountData);
            customerData.setSummaryData(customerSummaryData);

            return customerData;

        }).collect(Collectors.toList());

    }

    private void savingsAccount(AccountData accountData, String[] datas, Integer[] savingsAccountIndexes) {

        List<DataHolder> listOfData=accountData.getDataHolder();

        for(int i=0;i<savingsAccountIndexes.length-2;i++) {

            Integer indexToFetch=savingsAccountIndexes[i];

            if(!(accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getCapitalSharePercentage())||accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getReceivedInterestSharePercentage()))) {

                datas[indexToFetch]=formatData(datas[indexToFetch]);

            }else {
                datas[indexToFetch]=String.format("%.0f", Double.parseDouble(datas[indexToFetch]));
            }

            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(indexToFetch), "HeadingDefault"), (i==0)?datas[indexToFetch]+"%":datas[indexToFetch]));

        }

        Integer indexToFetch=savingsAccountIndexes.length;

        accountData.setBalanceShare(formatData(datas[savingsAccountIndexes[indexToFetch-2]]));
        accountData.setInterestShare(formatData(datas[savingsAccountIndexes[indexToFetch-1]]));

        ifAccountClosed(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getStatusText())], accountData);

    }

    private void loanAccount(AccountData accountData, String[] datas, Integer[] loanAccountIndexes) {

        List<DataHolder> listOfData=accountData.getDataHolder();

        for(int i=0;i<loanAccountIndexes.length-2;i++) {

            Integer indexToFetch=loanAccountIndexes[i];

            if(!(accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getCapitalSharePercentage())||accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getPaidInterestSharePercentage()))) {

                datas[indexToFetch]=formatData(datas[indexToFetch]);

            }else {
                datas[indexToFetch]=String.format("%.0f", Double.parseDouble(datas[indexToFetch]));
            }

            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(indexToFetch), "HeadingDefault"), datas[indexToFetch]));

        }

        Integer indexToFetch=loanAccountIndexes.length;

        accountData.setBalanceShare(formatData(datas[loanAccountIndexes[indexToFetch-2]]));
        accountData.setInterestShare(formatData(datas[loanAccountIndexes[indexToFetch-1]]));

        ifAccountClosed(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getStatusText())], accountData);

    }

    private void tillvaxtAccount(AccountData accountData, String[] datas, Integer[] tillvaxtAccountIndexes) {

        List<DataHolder> listOfData=accountData.getDataHolder();

        if(isAccountClosed(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getStatusText())]) || Double.valueOf(datas[getIndexOfHeading(accountDataHeadings, "ReceivedInterest")])>0 || Double.valueOf(datas[getIndexOfHeading(accountDataHeadings, "PreliminaryTax")])>0) {

            for(int i=0;i<tillvaxtAccountIndexes.length-2;i++) {

                Integer indexToFetch=tillvaxtAccountIndexes[i];

                if(!(accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getCapitalSharePercentage())||accountDataHeadings.get(indexToFetch).equalsIgnoreCase(headingsConfig.getReceivedInterestSharePercentage()))) {

                    datas[indexToFetch]=formatData(datas[indexToFetch]);

                }else {
                    datas[indexToFetch]=String.format("%.0f", Double.parseDouble(datas[indexToFetch]));
                }

                listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(indexToFetch), "HeadingDefault"), datas[indexToFetch]));

            }

            Integer indexToFetch=tillvaxtAccountIndexes.length;

            accountData.setBalanceShare(formatData(datas[tillvaxtAccountIndexes[indexToFetch-2]]));
            accountData.setInterestShare(formatData(datas[tillvaxtAccountIndexes[indexToFetch-1]]));

        }
        else {

            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(getIndexOfHeading(accountDataHeadings, "Balance")), "HeadingDefault"), formatData(datas[getIndexOfHeading(accountDataHeadings, "Balance")])));
            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(getIndexOfHeading(accountDataHeadings, headingsConfig.getCapitalSharePercentage())), "HeadingDefault"), String.format("%.0f", Double.parseDouble(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getCapitalSharePercentage())]))));

            Integer indexToFetch=tillvaxtAccountIndexes.length;
            accountData.setBalanceShare(formatData(datas[tillvaxtAccountIndexes[indexToFetch-2]]));

        }

    }

    private void borsAccount(AccountData accountData, String[] datas, Integer[] borsAccountIndexes) {

        List<DataHolder> listOfData=accountData.getDataHolder();

        if(isAccountClosed(datas[getIndexOfHeading(accountDataHeadings, headingsConfig.getStatusText())])) {

            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(getIndexOfHeading(accountDataHeadings, "InterestOverDesk")), "HeadingDefault"), formatData(datas[getIndexOfHeading(accountDataHeadings, "InterestOverDesk")])));
            listOfData.add(new DataHolder("Kapitalvinst", formatData(datas[getIndexOfHeading(accountDataHeadings, "ReceivedInterest")])));

        }
        else {

            listOfData.add(new DataHolder(headingsTranslation.getOrDefault(accountDataHeadings.get(getIndexOfHeading(accountDataHeadings, "Balance")), "HeadingDefault"), formatData(datas[getIndexOfHeading(accountDataHeadings, "Balance")])));

        }

    }

    private Integer[] loadIndexesForAccount(List<String> headings, String targetHeadings) {

        String accountHeaders[]= targetHeadings.split(",");

        Integer accountIndexes[]= new Integer[accountHeaders.length];
        int indexOfIndexes=0;

        for(String header : accountHeaders) {

            for(int i=0;i<headings.size();i++) {

                if(headings.get(i).equalsIgnoreCase(header)) {

                    accountIndexes[indexOfIndexes++]=i;
                    break;

                }

            }

        }

        return accountIndexes;

    }

    private boolean isAccountClosed(String statusText) {

        return statusText.equalsIgnoreCase("AVSLUTAD")||statusText.equalsIgnoreCase("AVSLUTAT");

    }

    private void ifAccountClosed(String statusText, AccountData accountData) {

        if(statusText.equalsIgnoreCase("AVSLUTAD")||statusText.equalsIgnoreCase("AVSLUTAT")) {

            accountData.getDataHolder().add(new DataHolder("Kontot avslutat", ""));

        }

    }

    private String formatData(String data) {

        try {

            Double doubleData=Double.parseDouble(data);

            return String.format("%,.2f", doubleData);

        }
        catch(NumberFormatException e) {

            return data;

        }

    }

    private String preceddingZeroRemover(char dataArray[]) {

        for(int i=0;i<dataArray.length;i++) {

            if(dataArray[i]!='0') {
                break;
            }

            dataArray[i]=' ';

        }

        return String.valueOf(dataArray).stripLeading();

    }

    private Integer getIndexOfHeading(List<String> headings, String heading) {

        if(headings.contains(heading)) {

            return headings.indexOf(heading);

        }

        throw new InvalidKeyException("Heading not found : "+heading);

    }

    private List<String> getFileData(String filePath) throws IOException {

        if(isFileExists(filePath)) {

            return Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);

        }

        throw new FileNotFoundException("File not found : [ "+filePath+" ]");

    }

    private Boolean isFileExists(String filePath) {

        return Files.exists(Paths.get(filePath));

    }

    private PathData validatePathdata(PathData pathData) throws FileNotFoundException, IllegalArgumentException, NullPointerException {

        if(pathData!=null) {

            if(pathData.getAccountDataCsv()!=null&&pathData.getSummaryDataCsv()!=null&&pathData.getDestPdfPath()!=null) {

                if(Files.exists(Paths.get(pathData.getAccountDataCsv()))&&Files.exists(Paths.get(pathData.getSummaryDataCsv()))) {

                    return pathData;

                }

                throw new FileNotFoundException("Some of the input files not found : [ "+ String.join(", ", pathData.getAccountDataCsv(), pathData.getSummaryDataCsv()) +" ]");

            }

            throw new IllegalArgumentException("Some of the input files paths are null : [ "+ String.join(", ", pathData.getAccountDataCsv(), pathData.getSummaryDataCsv()) +" ]");

        }

        throw new NullPointerException("Pathdata is null");

    }

    private void translationMapper() {

        if(headingsTranslation!=null) return;

        headingsTranslation=new LinkedHashMap<>();

        headingsTranslation.put("Interest1", "Aktuell räntesats");
        headingsTranslation.put("ReceivedInterest", "Inkomstränta");
        headingsTranslation.put("Balance", "Tillgodohavande");
        headingsTranslation.put("PreliminaryTax", "Preliminärskatt");
        headingsTranslation.put("CapitalSharePercentage", "Din andel av kapital");
        headingsTranslation.put("ReceivedInterestSharePercentage", "Din andel av ränta");
        headingsTranslation.put("PaidInterestSharePercentage", "Din andel av ränta");
        headingsTranslation.put("BalanceShare", "");
        headingsTranslation.put("ReceivedInterestShare", "");
        headingsTranslation.put("PaidInterest", "Utgiftsränta");
        headingsTranslation.put("Debth", "Skuld");
        headingsTranslation.put("InterestOverDesk", "Utbetalt belopp");

    }

}
